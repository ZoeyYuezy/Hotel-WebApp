<?php
//Connection
require('Database.php');
//Join
$query  = "SELECT Department.d_id, Department.d_name, Manager.m_name ";
$query .= "FROM Department ";
$query .= "INNER JOIN Manager ON Department.d_managerid = Manager.m_id ";
    $result = mysqli_query($connection, $query); 
if (!$result) {
    die("query is wrong");
}
?>
<div id ="menu">
            <li>Manager Menu</li>
        <li><a href="ManagerPage.php">Home</a></li>
        <li><a href="StaffPage.php">Staff</a></li>
        <li><a href="DepartmentPage.php">Department</a></li>
        <li><a href="ManagerPage1.php">Manager</a></li>
            </div>
<link rel="stylesheet" type="text/css" href="Style1.css"/>
<div class="Table"><table>
<thead>
    <td>Department ID</td>
    <td>Department</td>
    <td>Manager</td>
    </thead>

    
    <?php
while ($row = mysqli_fetch_array($result)) {
    echo "<tr>";
    echo "<td>" . $row["d_id"] . "</td>";
    echo "<td>" . $row["d_name"] . "</td>";
     echo "<td>" . $row["m_name"] . "</td>";
     echo "<td><a href='department-delete.php?id=" . $row['id'] . "'>Delete department</a></td>";
    echo "<td><a href='student-department.php?id=" . $row['id'] . "'>Update department</a></td>";
    echo "<td><a href='StaffPage.php?id=" . $row['id'] . "'>Show staffs</a></td>";
    echo "<td><a href='Maintainance.php?id=" . $row['id'] . "'>View department</a></td>";
    echo "</tr>";
}
    
    ?></table></div>

<?php
mysqli_close($connection);
?>