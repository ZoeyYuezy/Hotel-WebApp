<link rel="stylesheet" type="text/css" href="Style1.css"/><?php
require('Database.php');
$query = "SELECT * FROM Manager";




$result = mysqli_query($connection, $query);

if (!$result) {
    die("query is wrong");}

?>
<div id ="menu">
            <li>Manager Menu</li>
        <li><a href="ManagerPage.php">Home</a></li>
        <li><a href="StaffPage.php">Staff</a></li>
        <li><a href="DepartmentPage.php">Department</a></li>
        <li><a href="ManagerPage1.php">Manager</a></li>
            </div>
<link rel="stylesheet" type="text/css" href="Style1.css"/>
<div class="Table"><table>
<thead>
    <td>ID</td>
    <td>Name</td>
    <td>Level</td>
    </thead>

    
    <?php
while ($row = mysqli_fetch_array($result)) {
    echo "<tr>";
    echo "<td>" . $row["m_id"] . "</td>";
    echo "<td>" . $row["m_name"] . "</td>";
     echo "<td>" . $row["m_level"] . "</td>";
    echo "</tr>";
}
    
    ?></table></div>

<?php
mysqli_close($connection);
?>