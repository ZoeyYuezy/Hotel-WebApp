<link rel="stylesheet" type="text/css" href="Style1.css"/><?php
require('Database.php');
$query = "SELECT * FROM Staff";




$result = mysqli_query($connection, $query);

if (!$result) {
    die("query is wrong");}

?>
<div id ="menu">
            <li>Manager Menu</li>
        <li><a href="ManagerPage.php">Home</a></li>
        <li><a href="StaffPage.php">Staff</a></li>
        <li><a href="DepartmentPage.php">Department</a></li>
        <li><a href="ManagerPage1.php">Manager</a></li>
            </div>
<link rel="stylesheet" type="text/css" href="Style1.css"/>
<div class="Table"><table>
<thead>
    <td>ID</td>
    <td>Name</td>
    <td>Work time</td>
    <td>Phone number</td>
    </thead>

    
    <?php
while ($row = mysqli_fetch_array($result)) {
    echo "<tr>";
    echo "<td>" . $row["s_id"] . "</td>";
    echo "<td>" . $row["s_name"] . "</td>";
     echo "<td>" . $row["s_worktime"] . "</td>";
     echo "<td>" . $row["s_phonenumber"] . "</td>";
     echo "<td><a href='staff-delete.php?id=" . $row['id'] . "'>Delete staff</a></td>";
    echo "<td><a href='staff-update.php?id=" . $row['id'] . "'>Update staff</a></td>";   
    echo "</tr>";
}
    
    ?></table></div>

<?php
mysqli_close($connection);
?>