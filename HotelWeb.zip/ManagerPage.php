<html>
    <link rel="stylesheet" type="text/css" href="Style1.css"/>
    <head>
    <title>Welcome to Hotel Management</title>
    </head>
    <body>
        <div id ="menu">
            <li>Manager Menu</li>
        <li><a href="ManagerPage.php">Home</a></li>
        <li><a href="StaffPage.php">Staff</a></li>
        <li><a href="DepartmentPage.php">Department</a></li>
        <li><a href="ManagerPage1.php">Manager</a></li>
            </div>
    </body>
</html>

